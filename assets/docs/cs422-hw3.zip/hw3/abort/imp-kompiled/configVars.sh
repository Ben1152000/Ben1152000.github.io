#!/usr/bin/env bash

declaredConfigVar_STDIN='String'
declaredConfigVar_IO='String'
declaredConfigVar_PGM='Stmts'
declaredConfigVar_IO='String'
declaredConfigVars=(
    'STDIN'
    'IO'
    'PGM'
    'IO'
)
