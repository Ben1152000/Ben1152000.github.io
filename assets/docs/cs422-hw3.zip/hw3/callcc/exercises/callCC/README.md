---
copyright: Copyright (c) K Team. All Rights Reserved.
---

Define a variant of `callcc`, say `callCC`, which never returns to the
current context unless a value is specifically passed to its argument
continuation.  Follow a substitution-based style.
