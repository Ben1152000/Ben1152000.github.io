#!/usr/bin/env bash

declaredConfigVar_PGM='Stmt'
declaredConfigVar_STDIN='String'
declaredConfigVar_IO='String'
declaredConfigVar_IO='String'
declaredConfigVars=(
    'PGM'
    'STDIN'
    'IO'
    'IO'
)
