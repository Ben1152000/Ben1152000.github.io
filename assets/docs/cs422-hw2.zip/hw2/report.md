# Homework 2

For the sake of brevity, the lines which have been modified from the original code are included below:

## Exercise 1

The current K LAMBDA semantics of `mu` (in Lesson 8) is based on
substitution, and then `letrec` is defined as a derived operation using
`mu`.  Give `mu` a different semantics, as a derived construct by
translation into other LAMBDA constructs, like we defined `letrec` in
Lesson 7.

    rule mu X:KVar . E:Exp => ((lambda X . ((lambda X . E) (X X))) (lambda X . ((lambda X . E) (X X))))

## Exercise 2

Modify the K definition of IMP to not automatically initialize
variables to `0`.  Instead, declared variables should stay uninitialized
until assigned a value, and the execution should get stuck when an
uninitialized variable is looked up.  Specifically, you should add a
new `undefined` construct of sort `K`, and initialize all the declared
variables with it.

    syntax KItem ::= "undefined"

    rule <k> int (X,Xs => Xs);_ </k> <state> Rho:Map (.Map => X |-> undefined) </state>
      requires notBool (X in keys(Rho))

## Exercise 3

Modify IMP so that the K *followed by* arrow, `~>`, does not explicitly
occur in the definition (it currently occurs in the semantics of
sequential composition).

Hint: make sequential composition `strict(1)` or `seqstrict`, and have
statements reduce to `{}` instead of `.`; and don't forget to make
`{}` a `KResult` (you may need a new syntactic category for that, which
only includes `{}` and is included in `KResult`).

    syntax Empty ::= "{" "}"
    syntax Block ::= Empty
                  | "{" Stmt "}"

    syntax KResult ::= Int | Bool | Empty

    rule <k> X = I:Int; => {} ...</k> <state>... X |-> (_ => I) ...</state>

    rule {} S:Stmt => S

