---
copyright: Copyright (c) K Team. All Rights Reserved.
---

Maybe we should change the name of `calCC`, as it is not a good idea to have
two constructs with different semantics but names which cannot be distinguished
easily.
