#!/usr/bin/env bash

declaredConfigVar_PGM='Stmt'
declaredConfigVars=(
    'PGM'
)
