#!/usr/bin/env bash

declaredConfigVar_STDIN='String'
declaredConfigVar_IO='String'
declaredConfigVar_IO='String'
declaredConfigVar_PGM='Stmt'
declaredConfigVars=(
    'STDIN'
    'IO'
    'IO'
    'PGM'
)
