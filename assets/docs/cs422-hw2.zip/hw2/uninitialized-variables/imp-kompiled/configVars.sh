#!/usr/bin/env bash

declaredConfigVar_PGM='Pgm'
declaredConfigVars=(
    'PGM'
)
