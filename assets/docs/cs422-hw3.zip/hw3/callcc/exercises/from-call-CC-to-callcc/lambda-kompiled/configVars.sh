#!/usr/bin/env bash

declaredConfigVar_PGM='KItem'
declaredConfigVars=(
    'PGM'
)
